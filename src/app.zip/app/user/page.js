"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

export default function UserProfile() {
    const router = useRouter();
    const [userData, setUserData] = useState({
        username: "",
        email: "",
        first_name: "",
        last_name: "",
        birth_date: "",
        locality: "",
        municipality: "",
    });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        const token = localStorage.getItem("accessToken");
        if (!token) {
            router.push("/login");
            return;
        }

        fetch("https://das-p2-backend.onrender.com/api/users/profile/", {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
            },
        })
        .then((res) => res.json())
        .then((data) => {
            setUserData(data);
            setLoading(false);
        })
        .catch(() => {
            setError("Error al obtener los datos del usuario");
            setLoading(false);
        });
    }, [router]);

    if (loading) return <p>Cargando datos...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
        <main className="user-container">
            <section className="user-profile">
                <h2>Perfil de Usuario</h2>
                <div className="user-info">
                    <p><strong>Usuario:</strong> {userData.username}</p>
                    <p><strong>Correo Electrónico:</strong> {userData.email}</p>
                    <p><strong>Nombre:</strong> {userData.first_name}</p>
                    <p><strong>Apellidos:</strong> {userData.last_name}</p>
                    <p><strong>Fecha de Nacimiento:</strong> {userData.birth_date}</p>
                    <p><strong>Localidad:</strong> {userData.locality}</p>
                    <p><strong>Municipio:</strong> {userData.municipality}</p>
                </div>
                <button type="button" className="cta-button" onClick={() => router.push("/")}>Volver</button>
            </section>
        </main>
    );
}